const AutoDllPlugin = require('unplugin-auto-import/webpack')
const Components = require('unplugin-vue-components/webpack')
const { ElementPlusResolver } = require('unplugin-vue-components/resolvers')

// 第一个
module.exports = {
  configureWebpack: config => {
    // eslint-disable-next-line no-unused-expressions
    config.plugins.push(AutoDllPlugin({
      resolvers: [ElementPlusResolver()]
    }))
    config.plugins.push(Components({
      resolvers: [ElementPlusResolver()]
    }))
  }
}
