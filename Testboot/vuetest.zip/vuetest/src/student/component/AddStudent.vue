<template>
  <div>
    <!--添加-->
    <el-form :model="form" size="medium" ref="form" :rules="rules">
        <el-form-item label="工号">
          <el-input v-model="form.idcard" />
        </el-form-item>
        <el-form-item label="姓名">
          <el-input v-model="form.username" />
        </el-form-item>
        <el-form-item label="邮件">
          <el-input v-model="form.email" />
        </el-form-item>
        <el-form-item label="电话号码">
          <el-input v-model="form.phone" />
        </el-form-item>
        <el-form-item label="地址">
          <el-input v-model="form.address" />
        </el-form-item>
    </el-form>
    <div class="dialog">
      <el-button @click="dialogFormVisible = false" style="padding-top: 20px">取消</el-button>
      <el-button type="primary" @click="addStudent">确认</el-button>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data () {
    return {
      dialogFormVisible: false,
      form: {},
      formLabelWidth: '120px'
    }
  },
  methods: {
    addStudent () {
      // 验证表单数据
      this.$refs.form.validate(valid => {
        if (valid) {
          // 提交添加请求
          axios.post('http://localhost:9000/sUser/insert', this.form)
            .then(response => {
              if (response.status === 200 && response.data.success) {
                // 添加成功，将响应数据中的新数据加到表格数据中，并重置表单
                this.tableData.push(response.data.data)
                this.$message.success('添加成功')
              } else {
                // 添加失败，向用户显示相应的错误消息提示
                this.$message.error(response.data.message || '添加失败')
              }
            })
            .catch(error => {
              // 添加失败，向用户显示相应的错误消息提示
              this.$message.error('添加失败')
              console.error(error)
            })
        }
      })
    }
  }
}
</script>
<style scoped>

</style>
