<template>
  <div>
    <!-- 搜索框 -->
    <div style="padding: 10px 0">
      <el-card>
      <el-input style="width: 250px" placeholder="请输入名称" v-model="searchQuery"></el-input>
      <el-select
        style="margin-left: 5px"
        filterable
        allow-create
        default-first-option
        :reserve-keyword="false"
        placeholder="请输入或选择类型"
        v-model="searchType"
      >
        <el-option></el-option>
      </el-select>

      <el-button type="primary" style="margin-left: 5px" @click="search">
        <el-icon><Search /></el-icon>
        <span style="vertical-align: middle;">搜索</span>
      </el-button>
      <el-button  type="warning" @click="showAddDialog">新增 <el-icon ><circle-plus /></el-icon></el-button>
    </el-card>
    </div>

    <!-- 新增、批量删除、导入、导出按钮 -->
    <!-- <div style="padding: 10px 0">
      <el-button type="primary" @click="showAddDialog">新增 <el-icon style="margin-left: 3px"><circle-plus /></el-icon></el-button>
      <el-button type="danger" >批量删除 <el-icon style="margin-left: 3px"><delete /></el-icon></el-button>
      <el-upload action="http://127.0.0.1:8081/item/import" style="display: inline-block;margin-left: 10px">
        <el-popconfirm confirm-button-text="下载"
                       cancel-button-text="不用了"
                       icon-color="red"
                       title="是否需要下载导入模板？"
        >
          <template #reference>
            <el-button type="success">导入 <el-icon style="margin-left: 10px"><upload-filled /></el-icon></el-button>
          </template>
        </el-popconfirm>
      </el-upload>

      <el-button type="success" style="margin-left: 5px" @click="exportData">导出 <el-icon style="margin-left: 3px"><download /></el-icon></el-button>
    </div> -->
      <div class="type">
          <el-table  :data="currentPageData" :pagination="false" border style="width: 100%" @selection-change="handleSelectionChange">
            <el-table-column fixed type="selection" width="50%" align="center" />
            <el-table-column fixed prop="idcard" label="编号" width="100" sortable align="center" />
            <el-table-column prop="username" label="姓名" width="250" align="center" />
            <el-table-column prop="email" label="邮件" width="150" align="center" />
            <el-table-column prop="phone" label="电话" width="150" align="center" />
            <el-table-column prop="address" label="地址" width="200" sortable align="center" />
            <el-table-column prop="address" label="地址" width="200" sortable align="center" />
            <el-table-column prop="address" label="地址" width="200" sortable align="center" />
            <el-table-column prop="address" label="地址" width="200" sortable align="center" />
            <el-table-column prop="phone" label="电话" width="150" align="center" />
            <el-table-column prop="phone" label="电话" width="150" align="center" />
            <el-table-column el-table-column fixed="right" label="操作" width="300" align="center">
              <template v-slot="scope">
                <el-button @click="handleClick(scope.row)" type="success" size="default">编辑<el-icon><edit /></el-icon></el-button>
                <el-button @click="delOne(scope.row.idcard)" type="danger" size="default">删除<el-icon><remove /></el-icon></el-button>
              </template>
            </el-table-column>
          </el-table>
      </div>

    <!--分页-->
    <el-config-provider :locale="locale">
      <div style="padding: 10px 0">
        <el-pagination
          @size-change="handlePageSizeChange"
          @current-change="handleCurrentPageChange"
          :page-sizes="[6, 12, 18, 24]"
          :page-size="pageSize"
          :total="tableData.length"
          layout="sizes, prev, pager, next, jumper"
        ></el-pagination>
      </div>
    </el-config-provider>
    <!-- 增加对话框 -->
    <el-dialog v-model="dialogFormVisibleAdd" title="添加学生" width="50%">
      <!-- <addstudent />
            <el-button @click="dialogFormVisibleAdd = false" style="padding-top: 20px">取消</el-button>
           <el-button type="primary" @click="saveData('form')">确认</el-button> -->
      <el-form :model="form" size="medium" ref="form" :rules="rules">
        <el-form-item label="工号">
          <el-input v-model="form.idcard" />
        </el-form-item>
        <el-form-item label="姓名">
          <el-input v-model="form.username" />
        </el-form-item>
        <el-form-item label="邮件">
          <el-input v-model="form.email" />
        </el-form-item>
        <el-form-item label="电话号码">
          <el-input v-model="form.phone" />
        </el-form-item>
        <el-form-item label="地址">
          <el-input v-model="form.address" />
        </el-form-item>
    </el-form>
    <div class="dialog">
      <el-button @click="dialogFormVisibleAdd = false" style="padding-top: 20px">取消</el-button>
      <el-button type="primary" @click="addStudent">确认</el-button>
    </div>
    </el-dialog>
    <!-- 编辑对话框 -->
    <el-dialog title="物品信息" v-model="editdialogFormVisible" width="50%">
      <el-form :model="form" size="medium" ref="form">
        <el-form-item label="工号" :label-width="formLabelWidth" prop="id">
          <el-input v-model="form.idcard" autocomplete="off" disabled />
        </el-form-item>
        <el-form-item label="姓名" :label-width="formLabelWidth" prop="username">
          <el-input v-model="form.username" autocomplete="off" />
        </el-form-item>
        <el-form-item label="邮件" :label-width="formLabelWidth" prop="email">
          <el-input v-model="form.email" autocomplete="off" />
        </el-form-item>
        <el-form-item label="电话号码" :label-width="formLabelWidth" prop="phone">
          <el-input v-model="form.phone" autocomplete="off" />
        </el-form-item>
        <el-form-item label="地址" :label-width="formLabelWidth" prop="address">
          <el-input v-model="form.address" autocomplete="off" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer" style="padding-right: 40%">
          <el-button @click="editdialogFormVisible = false">取消</el-button>
         <el-button type="primary" @click="updateStudent()">确认</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>
<script>
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
// import addstudent from '../student/component/AddStudent.vue'
import axios from 'axios'
export default {
  data () {
    return {
      locale: zhCn,
      tableData: [],
      editdialogFormVisible: false,
      dialogFormVisibleAdd: false,
      form: {
        idcard: '',
        username: '',
        email: '',
        phone: '',
        address: ''
      },
      formLabelWidth: '120px',
      multipleSelection: [],
      searchQuery: '',
      searchType: '',
      pageSize: 6,
      currentPage: 1
    }
  },
  created () {
    axios.get('http://localhost:9000/sUser/all')
      .then(response => {
        this.tableData = response.data
      })
      .catch(error => {
        console.log(error)
      })
  },
  // components: {
  //   addstudent
  // },
  computed: {
    currentPageData () {
      const startIndex = (this.currentPage - 1) * this.pageSize
      const endIndex = startIndex + this.pageSize
      return this.tableData.slice(startIndex, endIndex)
    }
  },
  methods: {
    // 编辑用户对话框
    handleClick (row) {
      this.editdialogFormVisible = true
      this.form = Object.assign({}, row)
    },
    addStudent () {
      console.log('HTTP GET Request URL:', 'http://localhost:9000/sUser/add')
      console.log('HTTP GET Request Parameters:', this.form)
      axios.post('http://localhost:9000/sUser/add', this.form)
        .then(response => {
          if (response.status === 200) {
            this.tableData.push(response.data)
            this.$message.success('添加成功')
            this.dialogFormVisibleAdd = false
          } else {
            this.$message.error('添加失败')
          }
        })
        .catch(error => {
          this.$message.error('请求错误')
          console.error(error)
        })
    },
    updateStudent () {
      console.log('HTTP POST Request URL:', 'http://localhost:9000/sUser/updateId')
      console.log('HTTP POST Request Parameters:', this.form)
      axios.post('http://localhost:9000/sUser/updateId', {
        idcard: parseInt(this.form.idcard),
        username: this.form.username,
        email: this.form.email,
        phone: this.form.phone,
        address: this.form.address
      })
        .then(response => {
          if (response.status === 200) {
            const index = this.tableData.findIndex(item => item.idcard === this.form.idcard)
            if (index !== -1) {
              this.tableData.splice(index, 1, this.form)
            }
            this.$message.success('更新成功')
            this.editdialogFormVisible = false
          } else {
            this.$message.error('更新失败')
          }
        })
        .catch(error => {
          this.$message.error('请求错误')
          console.error(error)
        })
    },
    delOne (idcard) {
      this.$confirm('是否删除选中数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          axios.get(`http://localhost:9000/sUser/delete/${idcard}`)
            .then(response => {
              if (response.status === 200) {
                // 删除成功，从表格数据中删除该项
                this.tableData = this.tableData.filter(item => item.idcard !== idcard)
                // 显示删除成功的消息提示
                this.$message.success('删除成功')
              } else {
                // 请求成功但是删除失败，显示删除失败的消息提示
                this.$message.error('删除失败')
              }
            })
            .catch(error => {
              // 请求失败，显示请求错误的消息提示
              this.$message.error('请求错误')
              console.error(error)
            })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
    },
    handlePageSizeChange (pageSize) {
      this.pageSize = pageSize
      this.currentPage = 1
    },

    handleCurrentPageChange (currentPage) {
      this.currentPage = currentPage
    },
    showAddDialog () {
      this.dialogFormVisibleAdd = true
    }
  }
}
</script>
<style scoped>

</style>
