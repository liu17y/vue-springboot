<template>
  <div>
    <user-management-system @personal-center="handlePersonalCenter" @logout="handleLogout"></user-management-system>
  </div>
</template>

<script>
import BackHeader from '../components/BackHeader.vue'

export default {
  components: {
    BackHeader
  },
  methods: {
    handlePersonalCenter() {
      // 处理个人中心事件
    },
    handleLogout() {
      // 处理退出登录事件
    }
  }
}
</script>
