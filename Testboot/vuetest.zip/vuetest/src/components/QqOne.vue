<template>
  <div>
    <qrcode :value="wechatUrl" />
  </div>
</template>

<script>
import Qrcode from 'vue-qrcode'
export default {
  name: 'WeChat',
  components: {
    Qrcode
  },
  data () {
    return {
      wechatUrl: 'https://xui.ptlogin2.qq.com/cgi-bin/xlogin?pt_disable_pwd=1&pt_no_auth=1&appid=809041606&daid=338&s_url=https%3A%2F%2Fti.qq.com%2Fqqlevel%2Findex%3F' // 替换成你自己的微信链接
    }
  }
}
</script>
