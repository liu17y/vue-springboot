<template>
  <div class="background">
    <div class="el-cavas" >
      <div
         v-motion
         :initial="{ opacity: 0, x: -100 }"
         :enter="{ opacity: 1, x: 0 }"
         :delay="300"
    >
      <el-container class="el-container">
        <h1
          v-motion
          :initial="{ opacity: 0, y: -100 }"
          :enter="{ opacity: 1, y: 0, scale: 1 }"
          :variants="{ custom: {scale: 2}}"
          :hovered="{ scale: 1.2 }"
          :delay="300"
        >
          欢迎注册
        </h1>
        <el-form ref="form" :model="form" :rules="rules" label-width="80px">
          <el-form-item label="用户名" prop="username"
                        v-motion
                        :initial="{ opacity: 0, y: -100 }"
                        :enter="{ opacity: 1, y: 0, transition: {delay :400}}"
          >
            <el-input v-model="form.username" placeholder="请输入用户名"></el-input>
          </el-form-item>
          <el-form-item label="密码" prop="password"
                        v-motion
                        :initial="{ opacity: 0, y: -100 }"
                        :enter="{ opacity: 1, y: 0, transition: {delay :400}}"
          >
              <el-input type="password" v-model="form.password" placeholder="请输入密码"></el-input>
            </el-form-item>
            <el-form-item label="确认密码" prop="confirmPassword"
                          v-motion
                          :initial="{ opacity: 0, y: -100 }"
                          :enter="{ opacity: 1, y: 0, transition: {delay :400}}"
            >
              <el-input type="password" v-model="form.confirmPassword" placeholder="请再次输入密码"></el-input>
            </el-form-item>
            <el-form-item
              v-motion
              :initial="{ opacity: 0, y: -100 }"
              :enter="{ opacity: 1, y: 0, transition: {delay :400}}"
            >
              <el-button style="width:200px" type="primary" @click="register">注册</el-button>
              <div>
                <IdentifyCode ref="identifyCode" @click="refreshCode" />
              </div>
            </el-form-item>
            <div class="login-link"
                 v-motion
                 :initial="{ opacity: 0, y: -100 }"
                 :enter="{ opacity: 1, y: 0, transition: {delay :500}}"
            >
              已经有账号？<a href="#/login">登录</a>
            </div>
          </el-form>
        </el-container>
      </div>
    </div>
  </div>
</template>

<script>
import { ElMessage, ElForm, ElFormItem, ElInput } from 'element-plus'

export default {
  components: {
    ElForm,
    ElFormItem,
    ElInput
  },
  data () {
    return {
      form: {
        username: '',
        password: '',
        confirmPassword: '',
        email: ''
      },
      rules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 5, max: 10, message: '长度在 5 到 10 个字符', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 6, max: 10, message: '长度在 6 到 10 个字符', trigger: 'blur' }
        ],
        confirmPassword: [
          { required: true, message: '请再次输入密码', trigger: 'blur' },
          {
            validator: (rule, value, callback) => {
              if (value !== this.form.password) {
                callback(new Error('两次输入密码不一致'))
              } else {
                callback()
              }
            },
            trigger: 'blur'
          }
        ],
        email: [
          {
            required: true,
            message: '请输入邮箱',
            trigger: 'blur'
          },
          {
            type: 'email',
            message: '请输入正确的邮箱地址',
            trigger: ['blur', 'change']
          }
        ]
      }
    }
  },

  methods: {
    register () {
      this.$refs.form.validate(valid => {
        if (valid) {
          // TODO: 发送注册请求
          ElMessage({
            message: '注册成功',
            type: 'success'
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
  }
}
</script>

<style scoped>
.background {
  background-image: url('../assets/login-back.jpg');
  background-size: cover;
  background-position: center;
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
}

.el-cavas {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  height: 500px;
  width: 500px;
  background-color: rgb(255, 255, 255);
  border-radius: 10px;
  opacity: 0.7;
}

.el-span {
  font-size: 30px;
  font-weight: bold;
  padding-top: 200px;
}

.el-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100%;
  justify-content: center;
  padding-top: 50px;
}

.el-container h1 {
  font-size: 30px;
  font-weight: bold;
  padding-top: 20px;
}

.login-link {
  text-align: center;
  font-size: 20px;
  color: #9c9c9c;
  padding-left: 30px;
}
</style>
