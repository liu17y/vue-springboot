<template>
    <el-row :gutter="20" style="color: white">
      <el-col :span="2">
        <img src="../assets/logo.png" class="logo"/>
      </el-col>
      <el-col :span="20" style="font-size: 30px">用户管理系统</el-col>
      <el-col :span="2" style="text-align: right">
        <div class="toolbar">
          <span style="font-size: 24px">Tom</span>
          <el-dropdown>
<!--            <el-icon style="margin-right: 8px; margin-top: 1px; color: #ffffff; font-size: 24px" class="iconfont icon-shezhi"><setting/></el-icon>-->
            <el-icon style="margin-right: 8px; margin-top: 1px; color: #ffffff; font-size: 24px"><ArrowDown />
            </el-icon>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item @click="$emit('personal-center')">个人中心</el-dropdown-item>
                <el-dropdown-item @click="$router.push('/login')">退出登录</el-dropdown-item>
                <el-dropdown-item>Delete</el-dropdown-item>
                <el-dropdown-item>
<!--                  <el-button v-if="!loggedIn" type="primary" @click="login">登录</el-button>-->
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-col>
    </el-row>
</template>

<script>
export default {
  mounted () {
    this.$root.toggleNav()
    this.$emit('click')
  },
  beforeUnmount () {
    this.$root.toggleNav()
  }
}
</script>

<style scoped>
.logo{
  height: 80px;
}
.toolbar {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  text-align: center;
}
</style>
