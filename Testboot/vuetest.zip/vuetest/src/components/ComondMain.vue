<template>
  <div style="padding: 7px; background-color: #F7F7F7">
    <el-table :data="tableData" style="width: 100%">
      <el-table-column prop="date" label="日期" width="180"></el-table-column>
      <el-table-column prop="name" label="姓名" width="180"></el-table-column>
      <!--    <el-table-column prop="address" label="地址"></el-table-column>-->
      <el-table-column prop="number" label="学号"></el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  data () {
    const item = {
      date: '2023/5/12',
      name: 'uig',
      // address: '贵州中医药大学',
      number: '2020120104011'
    }
    return {
      tableData: Array(2).fill(item)
    }
  }
}
</script>
