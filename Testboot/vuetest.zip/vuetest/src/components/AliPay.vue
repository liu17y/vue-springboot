<template>
  <div>
    <qrcode :value="wechatUrl" />
  </div>
</template>

<script>
import Qrcode from 'vue-qrcode'
export default {
  name: 'WeChat',
  components: {
    Qrcode
  },
  data () {
    return {
      wechatUrl: 'https://mobile.alipay.com/index.htm?cid=wap_dc' // 替换成你自己的微信链接
    }
  }
}
</script>
