<template>
  <el-menu
    active-text-color="#ffd04b"
    background-color="#547599"
    class="el-menu-vertical-demo"
    default-active="2"
    text-color="#fff"
    @open="handleOpen"
    @close="handleClose"
    :default-openeds="['1', '3']"
    router
  >
    <el-menu-item :index="item.path" v-for="item in list" :key="item.path">
      <el-icon><House /></el-icon>
      <span>{{ item.meta.title }}</span>
    </el-menu-item>
    <el-sub-menu index="2">
      <template #title>
        <el-icon><Menu /></el-icon>商品管理
      </template>
      <el-menu-item-group>
        <el-menu-item index="2-1" @click="$router.push('/Home')">用户</el-menu-item>
        <el-menu-item index="2-2" @click="$router.push('/HomeTwo')">选项 2</el-menu-item>
      </el-menu-item-group>
      <el-sub-menu index="2-4">
        <template #title>选项 4</template>
      </el-sub-menu>
    </el-sub-menu>
    <el-sub-menu index="3">
      <template #title>
        <el-icon><LocationInformation /></el-icon>导航3
      </template>
      <el-menu-item index="3-1">其他1</el-menu-item>
      <el-menu-item index="3-2">其他2</el-menu-item>
    </el-sub-menu>
  </el-menu>
</template>

<script>
import { useRouter } from 'vue-router'

export default {
  setup () {
    const router = useRouter()
    console.log(router.getRoutes())
    const list = router.getRoutes().filter(v => v.meta.isShow)
    console.log(list)
    return { list }
  },
  // data () {
  //   return {
  //     isCollapse: false,
  //     menuData: [
  //       {
  //         path: '/',
  //         name: 'home',
  //         label: '首页',
  //         icon: 's-home',
  //         url: 'Home/Home'
  //       },
  //       {
  //         path: '/mall',
  //         name: 'mall',
  //         label: '商品1',
  //         icon: 'video-play',
  //         url: 'MallMange/MallMange'
  //       },
  //       {
  //         path: '/user',
  //         name: 'user',
  //         label: '用户管理',
  //         icon: 'user',
  //         url: 'UserMange/UserMange'
  //       },
  //       {
  //         label: '其他',
  //         icon: 'location',
  //         children: [
  //           {
  //             path: '/page1',
  //             name: 'page1',
  //             label: '页面1',
  //             icon: 'setting',
  //             url: 'Other/PageOne'
  //           },
  //           {
  //             path: '/page2',
  //             name: 'page2',
  //             label: '页面2',
  //             icon: 'setting',
  //             url: 'Other/PageTwo'
  //           }
  //         ]
  //       }
  //     ]
  //   }
  // },
  methods: {
    handleOpen (key, keyPath) {
      console.log(key, keyPath)
    },
    handleClose (key, keyPath) {
      console.log(key, keyPath)
    },
    // logout () {
    //   window.sessionStorage.clear()
    //   this.$router.push('/backmain')
    // },
    components: {
      // ...ElementPlusIconsVue
    }
  }
  // computed: {
  //   // 没有子菜单的
  //   noChildren () {
  //     return this.menuData.menuData.filter(item => !item.children)
  //   },
  //   // 有子菜单的
  //   hasChildren () {
  //     return this.menuData.menuData.filter(item => item.children)
  //   }
  // }
}
</script>
<!--<script setup>-->
<!--import { menuList } from "@/api/menu"-->

<!--const initMenuList = async () => {-->
<!--  const res = await menuList()-->
<!--  console.log(res)-->
<!--}-->
<!--initMenuList()-->
<!--</script>-->
<style>
.el-menu {
  width: 200px;
}
.el-menu-vertical-demo:not(.el-menu--collapse) .el-menu-item.active {
  background-color: #ffd04b;
  color:  #ffd04b;
}
</style>
