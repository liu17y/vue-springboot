import axios from 'axios'

export default {
  created() {
    axios.get('https://www.example.com')
      .then(response => {
        this.pageContent = response.data
      })
  },
  data() {
    return {
      pageContent: ''
    }
  }
}
