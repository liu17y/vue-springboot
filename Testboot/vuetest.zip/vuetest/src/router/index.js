import { createRouter, createWebHashHistory } from 'vue-router'

// // 导入nprogress
// import NProgress from 'nprogress'
// // 导入nprogress的css
// import 'nprogress/nprogress.css'
import Pageone from '../views/viewone/PageOne.vue'
import Pagetwo from '../views/viewone/PageTwo.vue'

const routes = [
  {
    path: '/',
    name: 'login',
    component: () => import('../views/HomeView.vue')
  },
  // 主路由
  {
    path: '/backend',
    name: 'backend',
    component: () => import('../views/BackFrom.vue'),
    // 二级路由
    children: [
      {
        path: 'backmain',
        name: 'backmain',
        meta: {
          isShow: true,
          icon: 'House',
          title: '首页'
        },
        // component: () => import('../components/ComondMain.vue')
        component: () => import('../student/StudentInfo.vue')
      },
      // 首页
      {
        path: 'Home',
        name: 'Home',
        meta: {
          isShow: false,
          icon: 'HomeFilled',
          title: '商品管理'
        },
        component: () => import('../views/viewone/HomeOne.vue')
      },
      {
        path: '/HomeTwo',
        name: 'HomeTwo',
        component: () => import('../student/ListInfo.vue')
      },
      // 用户管理
      // {
      //   path: 'backuser',
      //   name: 'backuser',
      //   meta: {
      //     isShow: true,
      //     title: '用户列表'
      //   },
      //   component: () => import('../views/Backfrom.vue')
      // },
      // 页面一
      { path: 'page1', component: Pageone },
      // 页面二
      { path: 'page2', component: Pagetwo }
    ]

  },
  {
    path: '/goods',
    name: 'goods',
    component: () => import('@/views/GoodsView.vue')
  },
  // {
  //   path: '/container',
  //   name: 'container',
  //   component: () => import('../components/FromBack.vue')
  // },
  {
    path: '/Register',
    name: 'Register',
    component: () => import('../components/RegisterLock.vue')
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})
//
// // 定义路由导航前置守卫
// router.beforeEach((to, from, next) => {
//   // 开启进度条
//   NProgress.start()
// })
// // 定义路由导后置守卫
// router.afterEach((to, from) => {
//   // 关闭进度条
//   NProgress.done()
// })

export default router
