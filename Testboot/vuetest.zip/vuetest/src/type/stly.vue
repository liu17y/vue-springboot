<style>
.honme-container{
  height: 100vh;
  overflow: hidden;
}
.el-header{
  background-color: #547599;
  color: #fff;
  height: 80px;
  line-height: 80px;
  text-align: center;
}
.el-aside {
  background-color: #547599;
  display: flex;
  flex-direction: column;
  color: white;
  padding-top: 80px;
}
.el-main{
  background-color: #ffffff;
  color: #fff;
}
</style>
