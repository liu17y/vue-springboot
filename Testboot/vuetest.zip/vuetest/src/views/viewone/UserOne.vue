<template>
  <el-sub-menu index="1" >
    <template #title>
      <el-icon class="iconfont icon-message"><message /></el-icon>角色管理
    </template>
    <el-menu-item-group>
      <el-menu-item index="1-1" @click="$router.push('/role')">用户内容页面 </el-menu-item>
      <el-menu-item index="1-2">选项 2</el-menu-item>
    </el-menu-item-group>
    <el-sub-menu index="1-4">
      <template #title>Option4</template>
      <el-menu-item index="1-4-1">Option 4-1</el-menu-item>
    </el-sub-menu>
  </el-sub-menu>
  <el-sub-menu index="2">
    <template #title>
      <el-icon class="iconfont icon-a-28icon_menu"><icon-menu /></el-icon>用户管理
    </template>
    <el-menu-item-group>
      <el-menu-item index="2-1" style="color: white">用户权限页面</el-menu-item>
      <el-menu-item index="2-2">选项 2</el-menu-item>
    </el-menu-item-group>
    <el-menu-item-group title="选项 2">
      <el-menu-item index="2-3">选项 3</el-menu-item>
    </el-menu-item-group>
    <el-sub-menu index="2-4">
      <template #title>选项 4</template>
      <el-menu-item index="2-4-1">选项 4-1</el-menu-item>
    </el-sub-menu>
  </el-sub-menu>
</template>

<script>
export default {
  setup () {
    return {}
  }
}
</script>

<style scoped>

</style>
