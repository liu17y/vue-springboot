<template>
<div>
  <h1>Mall</h1>
</div>
</template>

<script>

</script>

<style scoped>

</style>
