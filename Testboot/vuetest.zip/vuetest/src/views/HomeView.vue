<template>
  <div class="login">
    <div class="el-page-header">
      <div class="meituan-content">
        <div
          v-motion
          :initial="{ opacity: 0, x: -100 }"
          :enter="{ opacity: 1, x: 0 }"
          :delay="300"
        >
          <div class="common-layout">
            <el-container>
              <el-header class="el-alert__title">
                <!--              闪动效果-->
                <h3
                  v-motion
                  :initial="{ opacity: 0, y: -100 }"
                  :enter="{ opacity: 1, y: 0, scale: 1 }"
                  :variants="{ custom: {scale: 2}}"
                  :hovered="{ scale: 1.2 }"
                  :delay="300"
                >
                  WELCOME TO MY BLOG
                </h3>
              <el-container>
                <el-aside class="password-login" width="450px" >
                  <h1>密码登录</h1>
                  <el-form :rules="rules" label-width="80px"
                  ref="formRef"
                  :model="form"
                  >
                    <el-form-item label="用户名" prop="username"
                                  v-motion
                                  :initial="{ opacity: 0, y: -100 }"
                                  :enter="{ opacity: 1, y: 0, transition: {delay :400}}"
                    >
                      <el-input v-model="form.username" placeholder="请输入用户名">
                        <template #prefix>
                          <span class="iconfont icon-zhanghu"></span>
                        </template>
                      </el-input>
                    </el-form-item>
                    <el-form-item label="密码" prop="password"
                                  v-motion
                                  :initial="{ opacity: 0, y: -100 }"
                                  :enter="{ opacity: 1, y: 0, transition: {delay :400}}"
                    >
                      <el-input placeholder="请输入密码" v-model="form.password" type="password" show-password>
                        <template #prefix>
                          <span class="iconfont icon-password"></span>
                        </template>
                      </el-input>
                    </el-form-item>
                    <el-form-item label="验证码" prop="verificationCode"
                          v-motion
                          :initial="{ opacity: 0, y: -100 }"
                          :enter="{ opacity: 1, y: 0, transition: {delay :400}}"
                    >
                      <div class="check-code-panel">
                        <el-input type="text" v-model="form.verificationCode" placeholder="请输入验证码" class="input-panle">
                          <template #prefix>
                            <span class="iconfont icon-yanzhengma2"></span>
                          </template>
                        </el-input>
                      </div>
                      <IdentifyCode ref="identifyCode" @click="refreshCode" />
                    </el-form-item>
                    <el-form-item>
                      <el-checkbox v-model="form.rememberMe" :label="true" style=" font-size: 10px;"
                                   v-motion
                                   :initial="{ opacity: 0, y: -100 }"
                                   :enter="{ opacity: 1, y: 0, transition: {delay :400}}"
                      >
                        记住我
                      </el-checkbox>
                    </el-form-item>
                    <el-form-item type="login" v-model="form.Login" >
                      <div class="long-one">
                        <el-button type="primary" @click="login" class="login">登录</el-button>
                      </div>
                    </el-form-item>
                    <el-form-item type="rest">
                      <div class="login-link">
                        未有账号？<a href="#/Register">注册</a>
                      </div>
                    </el-form-item>
                  </el-form>
                </el-aside>
                <el-main class="qrcode-login"
                         v-motion
                         :initial="{ opacity: 0, y: -100 }"
                         :enter="{ opacity: 1, y: 0, transition: {delay :500}}"
                >
<!--                  <h2>微信二维码登录</h2>-->
<!--                  &lt;!&ndash;                <img id="qr-code" src="../assets/liuzongyi.png" alt="二维码">&ndash;&gt;-->
<!--                  <MyLoginComponent v-if="showRefreshBtn" @click="refreshQRCode" />-->
<!--                  <WeChat />-->
                  <h2>快捷登录</h2>
                  <el-row>
                    <el-col :span="8" style="padding-right: 10px">
                      <el-button
                        type="primary"
                        icon="el-icon-s-goods"
                        :class="{ 'is-active': currentLoginType === 'wechat' }"
                        @click="switchToWechat"
                      >
                        <h style="padding-right: 20px">微信</h>
                      </el-button>
                    </el-col>
                    <el-col :span="8">
                      <el-button
                        type="success"
                        icon="el-icon-s-claim"
                        :class="{ 'is-active': currentLoginType === 'qq' }"
                        @click="switchToQQ"
                      >
                        <h style="padding-right: 20px"> QQ</h>
                      </el-button>
                    </el-col>
                    <el-col :span="8">
                      <el-button
                        type="warning"
                        icon="el-icon-user-solid"
                        :class="{ 'is-active': currentLoginType === 'alipay' }"
                        @click="switchToWeibo"
                      >
                        <h style="padding-right: 20px"> 支付宝</h>
                      </el-button>
                    </el-col>
                  </el-row>
                  <div v-if="currentLoginType === 'wechat'" style="padding-top: 50px">
                    <WeChat />
                  </div>
                  <div v-else-if="currentLoginType === 'qq'" style="padding-top: 50px">
                    <QQ />
                  </div>
                  <div v-else-if="currentLoginType === 'alipay'" style="padding-top: 50px">
                    <Alipay />
                  </div>
                </el-main>
              </el-container>
              </el-header>
            </el-container>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { useRouter } from 'vue-router'
import { defineComponent, ref } from 'vue'
import { ElMessage } from 'element-plus'
// import IdentifyCode from '@/components/IdentifyCode.vue'
import WeChat from '@/components/WeChatone.vue'
import QQ from '@/components/QqOne.vue'
import Alipay from '@/components/AliPay.vue'

export default defineComponent({
  components: {
    WeChat,
    Alipay,
    QQ
  },
  setup () {
    const form = ref({
      username: 'admin',
      password: '123456',
      verificationCode: ''
    })

    const rules = {
      username: [
        { required: true, message: '请输入用户名', trigger: 'blur' },
        { min: 5, max: 10, message: '长度在 5 到 10 个字符', trigger: 'blur' }
      ],
      password: [
        { required: true, message: '请输入密码', trigger: 'blur' },
        { min: 6, max: 10, message: '长度在 6 到 10 个字符', trigger: 'blur' }
      ],
      verificationCode: [
        { required: true, message: '请输入验证码', trigger: 'blur' }
      ]
    }

    const currentLoginType = ref('wechat')

    const switchToWechat = () => {
      currentLoginType.value = 'wechat'
    }

    const switchToQQ = () => {
      currentLoginType.value = 'qq'
    }

    const switchToWeibo = () => {
      currentLoginType.value = 'alipay'
    }
    const formRef = ref()
    const router = useRouter()
    const login = () => {
      formRef.value.validate(async (valid) => {
        if (valid) {
          // 用户名和密码验证通过后，调用登录接口
          // 登录成功后，跳转到后端页面
          router.push('/backend', () => {
            // 在路由跳转完成后执行的回调函数中添加一些逻辑
            console.log('跳转成功')
          })
          ElMessage.success('登录成功')
        } else {
          console.log('error submit!!')
          return false
        }
        console.log(form)
      })
    }
    return {
      form,
      rules,
      currentLoginType,
      switchToWechat,
      switchToQQ,
      switchToWeibo,
      login,
      formRef
    }
  }
})
</script>

<style scoped>
.el-alert__title{
  font-size: 30px;
  font-weight: bold;
  color: #000000;
  padding-top: 10px;
  text-align: center;
  border-bottom: 1px solid #cccccc;
  height: 90px;
}
.el-page-header {
  background-image: url("../assets/login-back.jpg");
  position: absolute;
  width: 100%;
  height: 100%;
  background-size: cover;
  background-position: center;
  top: 0;
  left: 0;
  z-index: -1;
}
.meituan-content{
  position : relative;
  top : 50%;
  left : 50%;
  transform : translate(-50%,-50%);
  width : 1000px;
  height : 550px;
  background-color: #fcfcfc;
  border-radius: 10px;
  opacity: 0.8;
}
.common-layout {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
}

.password-login {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.password-login h1 {
  padding-top: 8px;
  padding-left: 50px;
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 20px;
  color: #000000;
}
.qrcode-login {
  display: flex;
  flex-direction: column;
  /*align-items: center;*/
  /*padding-bottom: 10px;*/
  text-align: center;
}
.qrcode-login h2 {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 20px;
  color: #000000;
}
#qr-code {
  width: 200px;
  height: 200px;
}
.long-one {
  padding-bottom: 30px;
  flex: 1;
  width: 100px;
}
.login {
  width: 100%;
  margin-top: 10px;
  border-radius: 10px;
}
.check-code-panel{
  display: flex;
}
.input-panle {
  flex: 1;
  width: 130px;
}
.check-code-panel {
  display: flex;
  align-items: center;
}
.input-panle {
  flex: 1;
}
.login-link {
  text-align: center;
  font-size: 20px;
  color: #cccccc;
  padding-left: 50px;
}
</style>
